# The Great Fall

A Pen created on CodePen.

Original URL: [https://codepen.io/cjgammon/pen/AEGmdo](https://codepen.io/cjgammon/pen/AEGmdo).

Example using webGL fixed background canvas with animations.  Camera moves with scroll position of page. Also utilizes clip paths and 2d canvas to draw and reveal polygon shapes for HTML content within page.